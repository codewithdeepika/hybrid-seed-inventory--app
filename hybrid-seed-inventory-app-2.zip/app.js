document.getElementById('inwardForm').addEventListener('submit', function (e) {
  e.preventDefault();
  const formData = new FormData(this);
  fetch('/api/inward', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(Object.fromEntries(formData))
  }).then(res => res.json()).then(data => alert(data.message));
});

document.getElementById('outwardForm').addEventListener('submit', function (e) {
  e.preventDefault();
  const formData = new FormData(this);
  fetch('/api/outward', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(Object.fromEntries(formData))
  }).then(res => res.json()).then(data => alert(data.message));
});

document.getElementById('returnsForm').addEventListener('submit', function (e) {
  e.preventDefault();
  const formData = new FormData(this);
  fetch('/api/returns', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(Object.fromEntries(formData))
  }).then(res => res.json()).then(data => alert(data.message));
});

document.getElementById('expiryForm').addEventListener('submit', function (e) {
  e.preventDefault();
  const formData = new FormData(this);
  fetch('/api/expiry', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(Object.fromEntries(formData))
  }).then(res => res.json()).then(data => alert(data.message));
});

function loadReports() {
  fetch('/api/reports')
    .then(res => res.json())
    .then(data => {
      document.getElementById('reportContent').textContent = JSON.stringify(data, null, 2);
    });
}