const express = require("express");
const app = express();
const path = require("path");

app.use(express.static(__dirname));
app.use(express.json());

let inwardData = [];
let outwardData = [];
let returnData = [];
let expiryData = [];

app.post("/api/inward", (req, res) => {
  inwardData.push(req.body);
  res.json({ message: "Inward entry added" });
});

app.post("/api/outward", (req, res) => {
  outwardData.push(req.body);
  res.json({ message: "Outward entry added" });
});

app.post("/api/returns", (req, res) => {
  returnData.push(req.body);
  res.json({ message: "Return entry added" });
});

app.post("/api/expiry", (req, res) => {
  expiryData.push(req.body);
  res.json({ message: "Expiry entry added" });
});

app.get("/api/reports", (req, res) => {
  res.json({ inwardData, outwardData, returnData, expiryData });
});

app.listen(3000, () => console.log("Server running on http://localhost:3000"));